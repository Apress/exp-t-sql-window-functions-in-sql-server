--9.4 Percent of Parent, Annual and Monthly sales
SELECT f.ProductKey, 
    YEAR(f.orderdate) AS OrderYear, 
    MONTH(f.orderdate) AS OrderMonth, 
    SUM(f.SalesAmount) AS [Sales Amt], 
    SUM(SUM(f.SalesAmount)) 
        OVER (PARTITION BY f.productkey) 
        / SUM(SUM(f.SalesAmount)) 
              OVER() AS [Product % of All Sales],
    SUM(SUM(f.SalesAmount)) 
        OVER (PARTITION BY f.productkey, YEAR(f.OrderDate))
        / NULLIF(SUM(SUM(f.SalesAmount)) 
                 OVER (PARTITION BY YEAR(f.OrderDate))
                ,0) AS [Product % Annual Sales],
    SUM(SUM(f.SalesAmount)) 
        OVER (PARTITION BY f.productkey, YEAR(f.OrderDate),
                MONTH(f.OrderDate))
        / NULLIF(SUM(SUM(f.SalesAmount)) 
                 OVER (PARTITION BY YEAR(f.OrderDate), MONTH(f.OrderDate))
		,0) AS [Product % Month Sales]
FROM dbo.FactInternetSales AS f
WHERE OrderDate BETWEEN '2011-01-01' AND '2012-12-31'
GROUP BY f.ProductKey, 
         YEAR(f.orderdate), 
         MONTH(f.orderdate)
ORDER BY 2, 3, f.ProductKey;
