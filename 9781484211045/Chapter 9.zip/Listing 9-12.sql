--9.12 Same Period Prior Year, Year-to-date calculations
WITH CTE_ProductPeriod 
AS  (
    SELECT p.ProductKey, Datekey, 
           CalendarYear, CalendarQuarter, 
           MonthNumberOfYear AS CalendarMonth
    FROM DimDate AS d
    CROSS JOIN DimProduct p
    WHERE d.FullDateAlternateKey BETWEEN '2011-01-01' AND GETDATE()
    AND EXISTS(SELECT * FROM FactInternetSales f 
                WHERE f.ProductKey = p.ProductKey 
                AND f.OrderDate BETWEEN '2011-01-01' AND GETDATE())
	),
CTE_MonthlySummary
AS (
    SELECT ROW_NUMBER() 
            OVER(ORDER BY p.CalendarYear, p.CalendarMonth) AS [RowID],
        p.CalendarYear AS OrderYear,
        p.CalendarMonth AS OrderMonth,
        count(distinct f.SalesOrderNumber) AS [Order Count],
        count(distinct f.CustomerKey) AS [Customer Count],
        ROUND(SUM(COALESCE(f.SalesAmount,0)), 2) AS [Sales Amt],
        ROUND(SUM(SUM(COALESCE(f.SalesAmount, 0)))
                OVER(PARTITION BY p.CalendarYear
                    ORDER BY p.CalendarYear, p.CalendarMonth
                    ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
                    ), 2) 
            AS [Sales Amt YTD],
    	ROUND(LAG(SUM(f.SalesAmount), 11, 0 ) 
                    OVER(ORDER BY p.CalendarYear, p.CalendarMonth), 2) 
            AS [Sales Amt SP PY],
        ROUND(LAG(SUM(f.SalesAmount), 1, 0)
                    OVER(ORDER BY p.CalendarYear, p.CalendarMonth), 2) 
            AS [Sales Amt PM],
	CASE WHEN COUNT(*) 
                    OVER(ORDER BY p.CalendarYear, p.CalendarMonth  
                          ROWS BETWEEN 2 PRECEDING AND CURRENT ROW) = 3
             THEN AVG(SUM(f.SalesAmount)) 
                    OVER(ORDER BY p.CalendarYear, p.CalendarMonth 
                         ROWS BETWEEN 2 PRECEDING AND current row) 
             ELSE null
	 END AS [Sales Amt 3 MMA],  -- 3 Month Moving Average
        CASE WHEN count(*) 
                    OVER(ORDER BY p.CalendarYear, p.CalendarMonth 
                         ROWS BETWEEN 2 PRECEDING AND current row) = 3
             THEN SUM(SUM(f.SalesAmount))
                    OVER(ORDER BY p.CalendarYear, p.CalendarMonth   
                         ROWS BETWEEN 2 PRECEDING AND current row) 
		ELSE null
         END AS [Sales Amt 3 MMT],   -- 3 month Moving Total
        CASE WHEN COUNT(*) 
                    OVER (ORDER BY p.CalendarYear, p.CalendarMonth  
                         ROWS BETWEEN 11 PRECEDING AND CURRENT ROW) = 12
             THEN AVG(SUM(f.SalesAmount)) 
                    OVER(ORDER BY p.CalendarYear, p.CalendarMonth 
                         ROWS BETWEEN 11 PRECEDING AND current row) 
             ELSE null
           END AS [Sales Amt 12 MMA], -- 12 Month Moving Average
        CASE WHEN count(*) 
                    OVER(ORDER BY p.CalendarYear, p.CalendarMonth 
			 ROWS BETWEEN 11 PRECEDING AND current row) = 12
        THEN SUM(SUM(f.SalesAmount)) 
                OVER (ORDER BY p.CalendarYear, p.CalendarMonth   
                        ROWS BETWEEN 11 PRECEDING AND current row) 
        ELSE null
      END AS [Sales Amt 12 MMT]   -- 12 month Moving Total
FROM CTE_ProductPeriod AS p
LEFT OUTER JOIN [dbo].[FactInternetSales] AS f
    ON p.ProductKey = f.ProductKey
    AND p.DateKey = f.OrderDateKey
GROUP BY p.CalendarYear, p.CalendarMonth
)
SELECT [RowID],
    [OrderYear],
    [OrderMonth],	
    [Order Count],
    [Customer Count],
    [Sales Amt],
    [Sales Amt SP PY],	
    [Sales Amt PM],
    [Sales Amt YTD],
    [Sales Amt 3 MMA],
    [Sales Amt 3 MMT],
    [Sales Amt 12 MMA],
    [Sales Amt 12 MMT],
    [Sales Amt] - [Sales Amt SP PY] AS [Sales Amt SP PY Diff],
    ([Sales Amt] - [Sales Amt SP PY]) 
        / NULLIF([Sales Amt SP PY], 0) AS [Sales Amt SP PY Pct Diff ],
    [Sales Amt] - [Sales Amt SP PY] AS [Sales Amt PY MOM Diff],
    ([Sales Amt] - [Sales Amt PM]) 
        / NULLIF([Sales Amt PM], 0) AS [Sales Amt PY MOM Pct Diff],
    LAG([Sales Amt YTD], 11,0)
	OVER(ORDER BY [OrderYear], [OrderMonth]) 
        AS [Sales Amt PY YTD],
    [Sales Amt YTD] - LAG([Sales Amt YTD], 11,0)
                          OVER(ORDER BY [OrderYear], [OrderMonth]) 
        AS [Sales Amt PY YTD Diff],
    ([Sales Amt YTD] - LAG([Sales Amt YTD], 11,0) 
                          OVER(ORDER BY [OrderYear], [OrderMonth])) 
            /NULLIF(LAG([Sales Amt YTD], 11, 0) 
                          OVER(ORDER BY [OrderYear], [OrderMonth]), 0) 
        AS [Sales Amt PY YTD Pct Diff]
FROM CTE_MonthlySummary
ORDER BY [OrderYear], [OrderMonth]
